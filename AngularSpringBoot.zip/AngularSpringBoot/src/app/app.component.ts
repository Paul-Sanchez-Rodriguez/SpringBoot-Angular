import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PersonaService } from './services/persona.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  personaForm!: FormGroup;
  est: any = 'A';
  persona: any;
  constructor(public fb: FormBuilder, public personaService: PersonaService) {

  }
  ngOnInit(): void {
    this.personaForm = this.fb.group({
      nombre: ['', Validators.required],
      apellidopat: ['', Validators.required],
      apellidomat: ['', Validators.required],
      estado: [this.est, Validators.required],
      celular: ['', Validators.required],
    });;

    this.personaService.listar().subscribe(res => {
      this.persona = res;
    },
      error => {
        console.error(error)

      });

  }
  guardar(): void {

    this.personaService.registrar(this.personaForm.value).subscribe(res => {
      this.personaForm.reset();
      this.persona.push(res);
    }, error => {
      console.error(error)
    })

  }

  eliminar(persona:any){
    this.personaService.eliminar(persona).subscribe(res=>{
      console.log(res)
      if(res=== true){
        this.persona.pop()
      }
    })
  }
}
