import { Injectable } from '@angular/core';
import {HttpClient}from '@angular/common/http';
import {Observable} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class PersonaService {

  private RUTA_SERVER = "http://localhost:8080/persona/";
  constructor(
    private httpClient: HttpClient
  ) { }

  public registrar(persona:any):Observable<any> {
    return this.httpClient.post(this.RUTA_SERVER,persona);
  }
  public listar():Observable<any> {
    return this.httpClient.get(this.RUTA_SERVER);
  }

  public eliminar(id: any):Observable<any>{
    return this.httpClient.delete(this.RUTA_SERVER +"delete/" +id);
  }
}
